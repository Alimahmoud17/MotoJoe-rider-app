#!/bin/bash

echo "🔹 إنشاء ملفات اللغة العربية..."

mkdir -p lib/l10n

cat > lib/l10n/app_ar.arb <<'EOT'
{
  "@@locale": "ar",
  "appTitle": "تطبيق التوصيل",
  "login": "تسجيل الدخول",
  "register": "إنشاء حساب",
  "home": "الرئيسية",
  "orders": "الطلبات",
  "profile": "الملف الشخصي",
  "logout": "تسجيل الخروج",
  "welcome": "مرحبًا بك",
  "newOrder": "طلب جديد",
  "delivered": "تم التوصيل",
  "notDelivered": "لم يتم التوصيل",
  "earnings": "الأرباح",
  "settings": "الإعدادات",
  "changeLanguage": "تغيير اللغة"
}
EOT

echo "🔹 استبدال النصوص الإنجليزية في المشروع بالعربية..."

find lib -type f -name "*.dart" -exec sed -i \
-e 's/Login/تسجيل الدخول/g' \
-e 's/Register/إنشاء حساب/g' \
-e 's/Home/الرئيسية/g' \
-e 's/Orders/الطلبات/g' \
-e 's/Profile/الملف الشخصي/g' \
-e 's/Logout/تسجيل الخروج/g' \
-e 's/Settings/الإعدادات/g' {} +

echo "✅ التطبيق أصبح عربي فصيح!"
